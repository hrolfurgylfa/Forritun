'''
Höfundur: Hrólfur Gylfason
Skilaverkefni 1 Liður 1
'''
#Hérna fæ ég nafn notandans
nafn=input("Hvað heitir þú? ")
#Hérna skrifa ég út textann til notans
print("Velkomin í áfangann FOR1TÖ3AU",nafn,"Þetta verður skemmtileg önn, ég hlakka til að læra forritun.")
print("Gaman að geta aðstoðað þig við þessa útreikninga",nafn)
