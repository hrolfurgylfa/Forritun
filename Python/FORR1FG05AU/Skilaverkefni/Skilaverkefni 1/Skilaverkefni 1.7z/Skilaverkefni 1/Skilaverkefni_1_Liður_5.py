'''
Höfundur: Hrólfur Gylfason
Skilaverkefni 1 Liður 5
'''
#Hérna fæ ég aldur sonsins og pabbans
aldur_sonur=int(input("Hversu gamall er sonurinn? "))
aldur_pabbi=int(input("Hversu gamall er pabbinn? "))
#Hérna reikna ég hvað pabbinn var gamall þegar hann eignaðist soninn
milli_aldur=aldur_pabbi-aldur_sonur
#Hérna segi ég notandanum hversu gamall pabbinn varð þegar hann eignaðist soninn
print("pabbinn var",milli_aldur,"ára þegar hann eignaðist soninn")
