'''
Höfundur: Hrólfur Gylfason
Skilaverkefni 1 Liður 2
'''
#Hérna bið ég notandan um kommutöluna
kommutala=float(input("Sláðu inn kommutölu með þrem aukastöfum "))
#Hérna sýni ég notandanum kommutöluna með einum auka staf
print("Þú hefur valið töluna:",round(kommutala,1))
