'''
Höfundur: Hrólfur Gylfason
Skilaverkefni 1 Liður 4
'''
#Hérna fæ ég lengd, hæð og breydd formsins
lengd=int(input("Hvað er lengd formsins? "))
breidd=int(input("Hvað er breidd formsins? "))
haed=int(input("Hvað er hæð formsins? "))
#Hérna geri ég útreykningana
rummal=lengd*breidd*haed
#Hérna sýni ég notandanum útkomuna
print("Rúmmál formsins er",rummal)
