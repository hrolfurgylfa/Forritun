'''
Höfundur: Hrólfur Gylfason
Skilaverkefni 1 Liður 3
'''
#Hérna fæ ég notandann til þess að skrifa inn tvær tölur
tala_1=int(input("Skráðu tölu 1 "))
tala_2=int(input("Skráðu tölu 2 "))
#Hérna margfalda ég og dreg tölurnar frá
margfoldun_summa=tala_1*tala_2
fradrattur_summa=tala_2-tala_1
#Hérna sýni ég notandanum niðurstöðurnar
print("Ef maður margfaldar þessar tölur saman þá fær maður",margfoldun_summa)
print("Ef maður dregur fyrri töluna frá þeirri seinni þá fær maður",fradrattur_summa)
